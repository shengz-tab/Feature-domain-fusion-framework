import json
import math

def parse_txt_and_generate_jsonl(input_file, output_file):
    """
    Parse a text file to extract protein names and sequences, and write them as JSON with NaN coordinates.

    Parameters:
        input_file (str): Path to the input .txt file.
        output_file (str): Path to the output .json file.
    """
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        for line in infile:
            # Split the line by comma and extract the relevant fields
            fields = line.strip().split(',')
            if len(fields) < 2:
                continue  # Skip malformed lines

            name = fields[0]
            seq = fields[1]
            length = len(seq)

            # Create the JSON structure
            coords_template = {
                "N": [[math.nan, math.nan, math.nan]] * length,
                "CA": [[math.nan, math.nan, math.nan]] * length,
                "C": [[math.nan, math.nan, math.nan]] * length,
                "O": [[math.nan, math.nan, math.nan]] * length
            }

            data_entry = {
                "name": name,
                "seq": seq,
                "coords": coords_template
            }

            # Write the JSON entry to the output file
            #json.dump(data_entry, outfile, indent=4)
            #outfile.write("\n")  # Add a newline between entries
            outfile.write(json.dumps(data_entry) + "\n")


test_input_file = "stability1/sequence_structure/sequence_test.txt"
test_output_file = "stability1/sequence_structure/structure_test.jsonl"

train_input_file = "stability1/sequence_structure/sequence_train.txt"
train_output_file = "stability1/sequence_structure/structure_train.jsonl"

dev_input_file = "stability1/sequence_structure/sequence_dev.txt"
dev_output_file = "stability1/sequence_structure/structure_dev.jsonl"

parse_txt_and_generate_jsonl(test_input_file, test_output_file)
print(f"结构已生成至 {test_output_file}")
parse_txt_and_generate_jsonl(train_input_file, train_output_file)
print(f"结构已生成至 {train_output_file}")
parse_txt_and_generate_jsonl(dev_input_file, dev_output_file)
print(f"结构已生成至 {dev_output_file}")

