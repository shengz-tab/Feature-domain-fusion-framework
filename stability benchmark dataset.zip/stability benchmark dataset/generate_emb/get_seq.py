import json
import random
# 输入 JSON 文件路径



test_input_file = "stability1/stability/stability_test.json"
test_output_file = "stability1/sequence_structure/sequence_test.txt"

train_input_file = "stability1/stability/stability_train.json"
train_output_file = "stability1/sequence_structure/sequence_train.txt"

valid_input_file = "stability1/stability/stability_valid.json"
valid_output_file = "stability1/sequence_structure/sequence_dev.txt"

# test
with open(test_input_file, "r") as file:
    test_data = json.load(file)

random.shuffle(test_data)

# 提取序列并按指定格式保存到文本文件
with open(test_output_file, "w") as file:
    for i, item in enumerate(test_data):
        stability_score = item['stability_score'][0] if isinstance(item['stability_score'], list) else item[
            'stability_score']
        file.write(f"test_{i},{item['primary']},{stability_score}\n")

print(f"序列已保存到 {test_output_file}")

# train
with open(train_input_file, "r") as file:
    train_data = json.load(file)

random.shuffle(train_data)

# 提取序列并按指定格式保存到文本文件
with open(train_output_file, "w") as file:
    for i, item in enumerate(train_data):
        stability_score = item['stability_score'][0] if isinstance(item['stability_score'], list) else item[
            'stability_score']
        file.write(f"train_{i},{item['primary']},{stability_score}\n")

print(f"序列已保存到 {train_output_file}")

# 从文件中读取 JSON 数据
with open(valid_input_file, "r") as file:
    valid_data = json.load(file)

random.shuffle(valid_data)

# 提取序列并按指定格式保存到文本文件
with open(valid_output_file, "w") as file:
    for i, item in enumerate(valid_data):
        stability_score = item['stability_score'][0] if isinstance(item['stability_score'], list) else item[
            'stability_score']
        file.write(f"dev_{i},{item['primary']},{stability_score}\n")

print(f"序列已保存到 {valid_output_file}")
