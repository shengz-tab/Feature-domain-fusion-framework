import os
import torch
import esm
import pickle
import argparse
import pandas as pd
import numpy as np


model, alphabet = esm.pretrained.esm_msa1b_t12_100M_UR50S()
batch_converter = alphabet.get_batch_converter()
model.eval()

src_dir = 'stability1/sequence_structure/'
seq_data_dir = os.path.join(src_dir, 'sequence_test.csv')

tgt_dir = 'stability1/sequence_structure/'
seq_save_dir = os.path.join(tgt_dir, 'sequence_test_emb')

trn_df = pd.read_csv(seq_data_dir)
trn_ids = trn_df['seq_id']
trn_seqs = trn_df['seq']

i = 1
for name, seq in zip(trn_ids, trn_seqs):
    print(f'[Train] processing the {i} seq named {name} to npy compressed...')
    seq = seq[:1022]
    seq = list(seq) + ['<eos>']
    data = [(name, seq)]
    batch_labels, batch_strs, batch_tokens = batch_converter(data)
    with torch.no_grad():
        results = model(batch_tokens, repr_layers=[12], return_contacts=True)
    token_representations = results["representations"][12]
    token_representations = token_representations.squeeze(0)
    token_representations = token_representations.squeeze(0)
    token_representations = token_representations.numpy()
    #np.savez_compressed(os.path.join(seq_save_dir, f'{name}.npy'), emb=token_representations)
    save_path = os.path.join(seq_save_dir, f'{name}.npy')  # 将文件扩展名设为 .npy
    np.save(save_path, token_representations)  # 使用 np.save 方法保存为 .npy 格式
    i += 1