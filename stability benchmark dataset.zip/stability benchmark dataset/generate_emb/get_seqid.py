test_input_file = "stability1/sequence_structure/sequence_test.txt"
test_output_file = "stability1/sequence_structure/id_test.txt"

train_input_file = "stability1/sequence_structure/sequence_train.txt"
train_output_file = "stability1/sequence_structure/id_train.txt"

dev_input_file = "stability1/sequence_structure/sequence_dev.txt"
dev_output_file = "stability1/sequence_structure/id_dev.txt"


# test
with open(test_input_file, "r") as file:
    first_column = [line.split(",")[0] for line in file]

# 将第一列内容保存到新文件
with open(test_output_file, "w") as file:
    for item in first_column:
        file.write(f"{item}\n")

print(f"第一列内容已保存到 {test_output_file}")

# train
with open(train_input_file, "r") as file:
    first_column = [line.split(",")[0] for line in file]

# 将第一列内容保存到新文件
with open(train_output_file, "w") as file:
    for item in first_column:
        file.write(f"{item}\n")

print(f"第一列内容已保存到 {train_output_file}")

#dev
with open(dev_input_file, "r") as file:
    first_column = [line.split(",")[0] for line in file]

# 将第一列内容保存到新文件
with open(dev_output_file, "w") as file:
    for item in first_column:
        file.write(f"{item}\n")

print(f"第一列内容已保存到 {dev_output_file}")
